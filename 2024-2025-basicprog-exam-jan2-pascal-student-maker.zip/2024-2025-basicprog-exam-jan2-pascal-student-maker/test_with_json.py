from model.ShopItemRepository import ShopItemRepository

print("\n***** 1) reading shopitems")
list_shopitems = ShopItemRepository.load_shopitems("doc/zalando_with_reviews.json")
print(f"Number of shopitems: {len(list_shopitems)}")
print(list_shopitems)

# print("\n****** 2) Look up shopitems in promotion:")
# searchresult = ShopItemRepository.filter_on_sale(list_shopitems)
# print(f"Result: {len(searchresult)} shopitems found")
# print(searchresult)

# print("\n****** 3) Count ratings per month:")
# dict_result = ShopItemRepository.count_ratings_per_month(list_shopitems)
# print(f"Result:{dict_result}")
# print("Overview:")
# for month_name, list_ratings in dict_result.items():
#     print(f"Month {month_name:10} -> Number of ratings: {len(list_ratings)}")

