from model.Product import Product
from model.Rating import Rating
class ShopItem(Product):
    def __init__(self, parname, parbrand, parsku, parprice,paron_sale,parsale_perc:float):
        super().__init__(parname, parbrand, parsku, parprice)
        self.on_sale = paron_sale
        self.sale_perc = parsale_perc
        self._ratings = []
        
    # ********** property on_sale - (setter/getter) ***********
    @property
    def on_sale(self) -> int:
        """ The on_sale property. """
        return self._on_sale
    
    @on_sale.setter
    def on_sale(self, value: int) -> None:
        if  not isinstance(value,int):
         raise TypeError("on-sale must be an integer")
        if not (0<= value <= 1):
            raise ValueError(" on_sale must be in the range 0 and 1") 
        self._on_sale = value
    
    # ********** property sale_perc - (setter/getter) ***********
    @property
    def sale_perc(self) -> float:
        """ The sale_perc property. """
        return self._sale_perc
    
    @sale_perc.setter
    def sale_perc(self, value: float) -> None:
        if not isinstance(value, float) or value <= 0:
         raise ValueError(" sale_perc must not be negative.")
        self._sale_perc = value
        
    
    # ********** property ratings - (getter only) ***********
    @property
    def ratings(self) -> list:
        """ The ratings property. """
        return self._ratings
    
    def add_rating(self, rating: Rating) -> None:
        if not isinstance(rating, Rating):
            raise TypeError("Rating must be an instance of Rating.")
        if rating in self.ratings:
            raise ValueError("Rating is already added.")
        self._ratings.append(rating)
    
    
    # ********** property sale_price - (getter only) ***********
    @property
    def sale_price(self) -> int:
        """ The sale_price property. """
        
        return self.__sale_price
    
        
    
    def __eq__(self, other: object) -> bool:
        return self,other.__str__()
    
    def __str__(self):
        return f" Shopitem {self.name} -sku {self.sku}"
    def __repr__(self) -> list:
        return f" Shopitem {self.name}"
        
    
    
        
        
    