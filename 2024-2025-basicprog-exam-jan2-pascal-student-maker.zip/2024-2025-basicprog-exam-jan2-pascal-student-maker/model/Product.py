class Product:
    def __init__(self,parname:str,parbrand:str,parsku:str,parprice:float):
        self.name = parname
        self.brand = parbrand
        self._sku = parsku
        self.price = parprice
        
    # ********** property name - (setter/getter) ***********
    @property
    def name(self) -> str:
        """ The name property. """
        return self._name
    
    @name.setter
    def name(self, value: str) -> None:
        if not isinstance(value, str):
         raise TypeError("Name must be a string.")
        if not value.strip():
         raise ValueError("Name must be non-empty.")
        self._name = value
    # ********** property brand - (setter/getter) ***********
    @property
    def brand(self) -> str:
        """ The brand property. """
        return self._brand.upper()
    
    @brand.setter
    def brand(self, value: str) -> None:
        if not isinstance(value, str):
         raise TypeError("brand must be a string.")
        if not value.strip():
         raise ValueError("brand must be non-empty.")
        self._brand = value
        
    
    # ********** property sku - (getter only) ***********
    @property
    def sku(self) -> str:
        """ The sku property. """
        return self._sku
    
    # ********** property price - (setter/getter) ***********
    @property
    def price(self) -> float:
        """ The price property. """
        return self._price
    
    @price.setter
    def price(self, value: float) -> None:
        if not isinstance(value, float) or value <= 0:
         raise ValueError("price must not be negative.")
        self._price = value
        
    
    def __eq__(self, other) -> bool:
       return (
            isinstance(other, Product)
            and self.name == other.name
            and self.brand == other.brand
            and self.sku == other.sku
            
        )
    
    
    def __lt__(self, other):
        if self.name != other.name:
            if self.name < other.name:
                return True
            else:
                return False
        else:
            if self.brand < other.brand:
                return True    
            else:
                return False
        
    
    def __str__(self) -> str:
        return f" Product: [{self.name}] ({[self.brand]}) -sku: [{self.sku}]"
    def __repr__(self) -> list:
        return f" Product [{self.name}] ({[self.brand]})"
        
        
    
