import datetime
class Rating:
    def __init__(self,parcurrent_rating:float,max_rating:int,pardate:datetime= datetime.date(2025,1,28),parcomments:str='no info available'):
        self.current_rating = parcurrent_rating
        self._max_rating = max_rating
        self.date = pardate
        self.comments = parcomments
        
    # ********** property current_rating - (setter/getter) ***********
    @property
    def current_rating(self) -> float:
        """ The current_rating property. """
        return self._current_rating
    
    @current_rating.setter
    def current_rating(self, value: float) -> None:
        if not isinstance(value, float) or value <= 0:
         raise ValueError("current rating must not be negative.")
        self._current_rating = value
    # ********** property max_rating - (getter only) ***********
    @property
    def max_rating(self) -> int:
        """ The max_rating property. """
        if  isinstance(self.max_rating, int) and self.max_rating > 0:
         return self._max_rating 
     
     # ********** property date - (setter/getter) ***********
    @property
    def date(self) -> datetime:
        """ The date property. """
        return self._date
     
    @date.setter
    def date(self,value):
                if not isinstance(value,(datetime.date,str)):
                 raise TypeError(" date must be a datetime object or a string")
                self._date = value()

         
    # ********** property comments - (setter/getter) ***********
    @property
    def comments(self) -> str:
        """ The comments property. """
        return self._comments
    
    @comments.setter
    def comments(self, value: str) -> None:
        if  not isinstance(value,str):
         raise TypeError ("comments must be string")
        if not value.strip():
            raise ValueError("comments must be a non empty string")
        self._comments = value
    
    # ********** property percentage_rating - (getter only) ***********
    @property
    def percentage_rating(self) -> type:
        """ The percentage_rating property. """
        self._percentage_rating =  (self.current_rating/self.max_rating) *100
        return  f" {self._percentage_rating}%"
    
    def __eq__(self, other) -> bool:
       return (
            isinstance(other, Rating)
            and self.current_rating == other.current_rating
            and self.max_rating == other.max_rating
            and self.date == other.date
            
        )
    
    def __lt__(self, other):
        return self.percentage_rating < other.percentage_rating
    
    def __str__(self):
       return f" Rating on date: [{self.current_rating}]/[{self.max_rating}] - Comments:{self.comments}"
   
    def __repr__(self) -> list:
        return f" Rating on date: {self.current_rating}"
       
           
    
     
    
    
        
        

    