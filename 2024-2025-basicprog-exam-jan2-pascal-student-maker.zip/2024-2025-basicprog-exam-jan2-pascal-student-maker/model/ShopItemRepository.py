import json
from model.ShopItem import ShopItem
from model.Rating import Rating
from typing import list
class ShopItemRepository:
    __filename = "doc/zalando_with_reviews.json"

    @staticmethod
    def __read_local_json_file():
        """Reads the local JSON file and returns its content."""
        with open(ShopItemRepository.__filename, encoding="utf8") as fo:
            return json.load(fo)

    @staticmethod
    def load_shopitems() -> list[ShopItem]:
        """Loads shopitems and their ratings."""
        all_shopitems_with_their_rating = []
        list_shopitems = ShopItemRepository.__read_local_json_file()  # JSON is a list of shopitems objects

        for dict_shopitems in list_shopitems:
            try:
                # Extract Shopitems details
                sku = dict_shopitems["sku"]
                name = dict_shopitems["name"]
                brand = (dict_shopitems["brand"])
                on_sale = int(dict_shopitems["on_sale"])
                regular_price = int(dict_shopitems["regular"])
                sale_percentage = int(dict_shopitems["sale_percentage"])
                

                # Create Shopitem object
                shopitem = ShopItem(sku , name, brand,on_sale, regular_price,sale_percentage)

                # Process associated reviews
                list_reviews = dict_shopitems.get("reviews", [])
                for dict_reviews in list_reviews:
                    current_date = str(dict_reviews["current_date"])
                    date = str(dict_reviews["date"])
                    comment = (dict_reviews["comment"])
                    max_rating = int(dict_reviews["max_rating"])

                    
                    # Create Review object
                    review = Rating(
                        current_date,
                        date,
                        comment,
                        max_rating,
                    )

                    # Add  review to the shopitem
                    shopitem.add_rating(review)

                # Add shopitems object to the list
                all_shopitems_with_their_rating.append(shopitem)

            except KeyError as e:
                print(f"Missing key {e} in Shop data: {dict_reviews}")
            except ValueError as e:
                print(f"Invalid data format in shop or review data: {dict_shopitems}")

        return all_shopitems_with_their_rating
    
    
    @staticmethod
    def filter_on_sale(list_shopitems):
      filtered_sales = []
      for item in list_shopitems:
        if any():
          filtered_sales.append(item)
          
      return filtered_sales
  
  
    
     
    @staticmethod
    def sort_ratings_on_month(list_shopitems) -> dict:
      
      for key,value in  list_shopitems.items():
          print
        
      