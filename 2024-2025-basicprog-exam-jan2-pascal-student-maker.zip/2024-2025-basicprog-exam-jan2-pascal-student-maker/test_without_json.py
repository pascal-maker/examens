from model.Product import Product
from model.Rating import Rating
from model.ShopItem import ShopItem
from datetime import datetime



def create_products():
    print("\n*** Test 1 ***")
    #Test product klasse
    product1 = Product("Howest MCT T-shirt", "Oakley", "woo_vneck_tshirt_MCT", 12.0)
    print(product1)

    product2 = Product("Howest MCT T-shirt", "Oakley", "woo_vneck_tshirt_MCT", 15.0)
    print(product2)

    if product1 == product2:
        print("Product 1 & 2 are equal")
    else:
        print("Product 1 & 2 are not equal")


def create_ratings():
    print("\n*** Test 2 ***")
    #Test Rating klasse
    rating_1 = Rating(3.5,10,datetime(2025,1,31),"Moderate")
    rating_2 = Rating(1.5, 5,datetime(2025,2,14),"very bad")
    rating_3 = Rating(2.5,5,datetime(2024,11,18))
    list_ratings = [rating_1, rating_2, rating_3]
    print(f"Unsorted: {list_ratings}")
    list_ratings.sort()
    print(f"\nSoring a list of ratings:")
    for r in list_ratings:
        print(r)
        print(f"\tRating has a score percentage of {r.percentage_rating}%.")


def create_shopitem():
    print("\n*** Test 3 ***")
    rating_1 = Rating(3.5,10,datetime(2025,1,31),"Moderate")
    rating_2 = Rating(1.5, 5,datetime(2025,2,14),"very bad")
    shopitem1 = ShopItem("Howest MCT T-shirt", "Oakley", "woo_vneck_tshirt_MCT", 117.0, 1, 10)
    shopitem1.add_rating(rating_1)
    shopitem1.add_rating(rating_2)
    print(shopitem1)
    print(f"Normal price: {shopitem1.price}€ -> Sale price: {shopitem1.sale_price:.1f}€")
    print(shopitem1.shopdata())


def create_list_shopitems():
    print("\n*** Test 4 ***")
    #test list van ShopItem klasse
    shopitem1 = ShopItem("Howest MCT T-shirt", "Oakley", "woo_vneck_tshirt_MCT", 12.0, 1, 10)
    shopitem2 = ShopItem("Howest MCT Hoodie", "Nike", "woo_hoodie_MCT", 18.0, 0, 5)
    shopitem3 = ShopItem("Howest MCT Jacket", "Omega", "woo_jacket_MCT", 34.0, 1, 10)

    my_list = [shopitem1, shopitem2, shopitem3]
    print(f"Sorted: {my_list}")
    my_list.sort()
    print(f"Not sorted: {my_list}")

def create_errors():
    print("\n*** Test 5 - Wrong input ***")
    try:
        shopitem1 = ShopItem("Howest MCT T-shirt", "Oakley", "woo_vneck_tshirt_MCT", 12.0, 1000, 10)
        shopitem1.add_rating("Very nice!")
        print(shopitem1)
    except Exception as ex:
        print(f"Error: {ex}")


create_products()
# create_ratings()
# create_shopitem()
# create_list_shopitems()
# create_errors()